export interface Hero {
  name: string;
}

export const HEROES = [
  {name: 'Dr IQ'},
  {name: 'Magneta'},
  {name: 'Bombasto'}
];
