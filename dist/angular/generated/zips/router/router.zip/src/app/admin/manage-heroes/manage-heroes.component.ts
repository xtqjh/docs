import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-hereos',
  templateUrl: './manage-heroes.component.html',
  styleUrls: ['./manage-heroes.component.css']
})
export class ManageHeroesComponent { }
